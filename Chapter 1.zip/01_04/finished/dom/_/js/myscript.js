console.assert(
	document.querySelectorAll('nav ol>li').length===3,
	"Sorry, there's only two menu items"
);